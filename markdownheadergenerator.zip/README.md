# Markdown Header Generator

Gere automaticamente uma imagem personalizada com avatar sobreposto no banner de fundo, pronta para usar como cabeçalho de perfil ou README.

## Uso

URL:


